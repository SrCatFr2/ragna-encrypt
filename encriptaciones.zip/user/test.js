// tests/testUser.js
const connectDB = require('../src/db/connection'); // Asegúrate de que esto conecta a tu DB
const User = require('../src/db/userModel'); // Ajusta la ruta si es necesario

async function test() {
  // Conecta a la base de datos
  await connectDB();

  // Crear un nuevo usuario
  const newUser = new User();
  await newUser.save(); // Guarda el usuario en la base de datos

  // Muestra información del usuario recién creado
  newUser.displayInfo();

  // Busca el usuario por su ID
  const foundUser = await User.findById(newUser._id);
  if (foundUser) {
    console.log('Usuario encontrado:', foundUser);
  } else {
    console.log('Usuario no encontrado');
  }
}

test();
